.. cmake-module:: ../../Modules/CheckOBJCSourceRuns.cmake
